<?php

    $con = mysqli_connect("localhost","root","","webdb") or die ("Cannot connect to server");

    $name = $_POST['names'];
    $os = $_POST['os'];
    $php = $_POST['php'];
    $web = $_POST['web'];

    $sql = "insert into students VALUES ('$name','$os','$php','$web')";
    $status = mysqli_query($con,$sql) or die ("Error in inserting data due to ".mysqli_error($con));

    if($status){
        echo ("Your data has been finally inserted into our database");
    }else{
        display_error ("Error when inserting data");
    }
?>